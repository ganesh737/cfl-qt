#include <QCoreApplication>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //Nothing to see here - download and install Qt

    return a.exec();
}
