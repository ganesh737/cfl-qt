#include <QTest>
#include "widget.h"

//Update .Pro file:  QT += testlib

QTEST_MAIN(Widget);
